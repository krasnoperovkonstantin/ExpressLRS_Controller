# Bootloader
 Supports Express LRS application code update using XMODEM protocol.


 This version forked from nice [STM32-bootloader](https://github.com/ferenc-nemeth/stm32-bootloader) project.

 Big thanks to original author @ferenc-nemeth !
